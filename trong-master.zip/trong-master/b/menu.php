<div class="item"><a href="/tien-ich/code.php"><img src="/images/next.png"/> Xem Mã Nguồn</a></div>
<div class="item"><a href="/tien-ich/code2.php"><img src="/images/next.png"/> Xem Mã Nguồn Part 2</a></div>
<div class="item"><a href="/tien-ich/van-ban.php"><img src="/images/next.png"/> Sửa văn bản online (tìm văn bản , từ ngữ , kí tự,... rồi thay thế chúng hoặc xóa bỏ)</a></div>
<div class="item"><a href="/tien-ich/css.php"><img src="/images/next.png"/> Sửa css (Sửa css theo nhiều khung nhỏ)( hỗ trợ cho máy max 5000 kí tự)</a></div>
<div class="item"><a href="/tien-ich/ma-hoa.php"><img src="/images/next.png"/> Mã Hóa md5/sha1 </a></div>
<div class="item"><a href="/tien-ich/chuyen.php"><img src="/images/next.png"/> Chuyển đổi văn bản HTML sang TEXT và ngược lại </a></div>
