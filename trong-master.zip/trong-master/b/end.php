<div class="header"><b><a href="/">Trang Chủ</a>| <a href="/">Danh Sách Tiện Ích</a></div><div class="item"><center><b style="color:green">© 2016 - Wap Tiện Ích <?php
include "view.php";?></b><br/><b style="color:orange">Design By ADS</b></strong></center></div>
</body></html>
<style type='text/css'>#bttop{position:fixed;bottom:5px;right:10px;z-index:9999999999;}</style>
<div id='bttop'><a><img src="http://i.imgur.com/SykcvFs.png" /></a></div>
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js' type='text/javascript'></script>
<script type='text/javascript'>$(function(){$(window).scroll(function(){if($(this).scrollTop()!=0){$('#bttop').fadeIn();}else{$('#bttop').fadeOut();}});$('#bttop').click(function(){$('body,html').animate({scrollTop:0},800);});});</script>
