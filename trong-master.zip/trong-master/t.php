<?php 

// Mệnh đề if này không được thực hiện
// biến $sologan ko tồn tại
$website = 'freetuts.net';

    $sologan = 'Đây không phải là website freetuts.net';

  
// Nên đoạn code này sai
$sologan .= ' vui lòng ghi rõ nguồn khi public nội dung này ở website khác';

 
?>