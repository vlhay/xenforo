<?php error_reporting(E_ALL & ~E_NOTICE);
 session_start();
$title = 'Wap Tiện ích Online';
include 'b/head.php';
echo '<div class="item"><img src="/images/next.png"/><b style="color:green"> Chào mừng bạn đến với wap tiện ích online BACU.GA wap đang trong quá trình xây dựng</b></div>';

include 'b/menu.php';
include 'b/end.php';
?>